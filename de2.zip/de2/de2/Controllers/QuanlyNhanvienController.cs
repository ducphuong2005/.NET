﻿using de2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace de2.Controllers
{
    public class QuanlyNhanvienController : Controller
    {
        // GET: QuanlyNhanvien
        List<Nhanvien> danhsach;
        public QuanlyNhanvienController()
        {
            danhsach = new List<Nhanvien>
            {
                new Nhanvien("nv01", "Nguyễn Vân Anh", "Hà Nội", 15, 200000),
                new Nhanvien("nv02", "lê Thu Hà", "Hải Phòng", 27, 250000),
                new Nhanvien("nv03", "Nguyễn Văn Hoàng", "Hà Nội", 18, 250000),
                new Nhanvien("nv04", "Trần Nguyệt Nhi", "Hải Phòng", 25, 190000),
                new Nhanvien("nv05", "Nguyễn Lam Chi", "Quảng Ninh", 20, 180000),
            };
        }
        public ActionResult Index()
        {
            ViewBag.ds1 = danhsach.Where(nv => nv.songaylam < 20).ToList();
            ViewBag.ds2 = danhsach.Where(nv => nv.luongngay > 190000).ToList();
            return View();
        }

        public ActionResult Input()
        {
            return View();
        }

        public ActionResult Output(Nhanvien nhanvien)
        {
            return View(nhanvien);
        }
    }
}